1) In omega terminal, cd to the directory where the cpp code is kept.

2) Compile the code with the command below

g++ dtw_classify.cpp -o out

3) See the output of the code with below command:

./out <training_file_path> <test_file_path>